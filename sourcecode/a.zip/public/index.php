<?php
require_once __DIR__ . '/../app/helpers/EnvHelper.php';
require_once '../app/bridge.php';
session_start();
$route = new Router();
